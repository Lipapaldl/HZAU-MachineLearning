import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.io import loadmat  #用于加载MATLAB格式的数据集

#导入数据
data = loadmat('ex3data1.mat')
X = data['X'] #一共5000个样本，每个样本是20*20像素的数字。20×20展开是400维的向量
y = data['y']
X.shape, y.shape  #期待输出((5000, 400), (5000, 1))

#数据可视化
def plot_an_image(X):
    pick_one = np.random.randint(0, 5000) #随机生成范围内一个数
    image = X[pick_one, :]  #取第pick_one个样本
    fig, ax = plt.subplots(figsize=(1, 1))
    ax.matshow(image.reshape((20, 20)), cmap='gray_r')  #matshow可将矩阵坐标转化成像素图
    plt.xticks([])  # 去掉坐标轴刻度，美观
    plt.yticks([])
    plt.show()
    print('this should be {}'.format(y[pick_one]))
    
    




#接下来的是通过神经网络方法计算（权重已经训练好）

#初始化数据
def load_data(path):
    data = loadmat(path)
    X = data['X']
    y = data['y']
    return X,y

X, y = load_data('ex3data1.mat')  #X等会要插入一组等于1的数组，用于计算Bias偏置
y = y.flatten()  #将y变成一维数组
X = np.insert(X, 0, values=np.ones(X.shape[0]), axis=1)  #X是插入的数组，0是插入的位置，之后是插入的内容，axis是哪一个轴上对应的位置

#初始化已知的权重
def load_weight(path):
    data = loadmat(path)
    return data['Theta1'], data['Theta2']

theta1, theta2 = load_weight('ex3weights.mat')  #加载权重参数


def sigmoid(z):  
    return 1 / (1 + np.exp(- z))

#开始计算各层网络：我用的是笔记上的那种矩阵格式，与网站上的不同。
a1=X.T  #a1.shape是（401,5000）
a2=sigmoid(np.dot(theta1,a1))
a2=np.insert(a2,0,values=np.ones(a2.shape[1]),axis=0)  #在第一行，插入长度为a2列数的数组（全是1）
a3=sigmoid(np.dot(theta2,a2))
predict=np.argmax(a3,axis=0)+1  #argmaxs是返回沿轴axis最大值的索引。加1是因为索引是从0开始的
accuracy=np.mean(predict==y)  #计算估计值和真实值相等的比例，结果为0.9752























