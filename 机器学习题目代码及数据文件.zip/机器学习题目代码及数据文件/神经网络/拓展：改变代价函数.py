#正则化是加在cost上的，梯度的正则化是cost函数的正则化的导数。
#正则化那个式子是人为设置的，感觉想怎么设置就怎么设置？
#去掉正则化后过拟合，侧精度值肯定是很高的。本次的正则化按上一次的乘上0.01，不然正则化过头了，精度太低。

def cost(theta, X, y):
    a1, z2, a2, z3, h = feed_forward(theta, X)  
    J=(y-h.T)**2
    return J.sum()/len(X)/2

def regularized_cost(theta, X, y, l=1):
    t1, t2 = load_weight('ex4weights.mat')
    reg = np.sum(t1[:,1:] ** 2) + np.sum(t2[:,1:] ** 2)   #正则化的公式在网站上
    return l / (2 * len(X)) * reg*0.01 + cost(theta, X, y)



    
def gradient(theta, X, y):  #不加l=1的话那个优化参数用不了，那个是要求有四个参数。那个的具体参数用法哥不知道。
    t1, t2 = deserialize(theta)  #这里debug了一天，当时忘写了。每次都是要更新t1和t2的，忘了写导致优化速度很快，即少了更新这部
    a1, z2, a2, z3, h = feed_forward(theta, X)
    d3 = (h.T - y)*sigmoid_gradient(z3.T)  #(5000, 10)  #dn是指第n层的误差
    d2 = np.dot(d3,t2[:,1:] )* sigmoid_gradient(z2.T)  #(5000,25)
    D3=np.dot(a2,d3).T  # (10, 26)  #D3是指代价函数关于传到第3层的权重的偏导数/改变率。要不要转置，变成权重的维度一样就行
    D2=np.dot(a1,d2).T  # (25, 401)
    D = (1 / len(X)) * serialize(D2, D3)  # (10285,)
    return D
    
def regularized_gradient(theta, X, y, l=1):
    """不惩罚偏置单元的参数"""
    a1, z2, a2, z3, h = feed_forward(theta, X)
    D2, D3 = deserialize(gradient(theta, X, y))
    t1[:,0] = 0  #即把偏置单元的参数变成0
    t2[:,0] = 0
    reg_D2 = D2 + (l / len(X)) * t1*0.01
    reg_D3 = D3 + (l / len(X)) * t2*0.01
    return serialize(reg_D2, reg_D3)

    
    
def nn_training(X, y):
    init_theta = random_init(10285)  # 25*401 + 10*26
    res = opt.minimize(fun=regularized_cost,
                       x0=init_theta,
                       args=(X, y, 1),
                       method='TNC',
                       jac=regularized_gradient,
                       options={'maxiter': 400})
    return res

    
    
res = nn_training(X, y)

def accuracy(theta, X, y):
    _, _, _, _, h = feed_forward(res.x, X)
    y_pred = np.argmax(h.T, axis=1) + 1
    print(classification_report(y, y_pred))

accuracy(res.x, X, raw_y)