#直接从90行那开始看。前部分都是定义各种函数(前半部分读取的数据是用来测试的)。
#本质上就是我得到各观众对各电影的评分Y，然后使X@Theta.T与真实值Y相减的平方最小，求出X和Theta，再通过X@Theta.T得出预测值
import pandas as pd
import numpy as np
from scipy.io import loadmat
import matplotlib.pyplot as plt


#读取Y、R的数据
mat = loadmat('ex8_movies.mat')
print(mat.keys())
Y, R = mat['Y'], mat['R']  #Y是不同观众给不同电影的分数(0是没打分)。R中是不同观众给不同电影有无打分(0是没打1是打过)
nm, nu = Y.shape  # Y中0代表用户没有评分。nm是电影数量，nu是用户数量
nf = 100  #即每个电影和用户的特征向量是100维度
Y.shape, R.shape  #((1682, 943), (1682, 943))

Y[0].sum() / R[0].sum()  # 第一个电影评分的平均值。分子代表第一个电影的总分数，分母代表这部电影有多少人评分过

# 可视化Y的数据先(感觉没用)，就是用Y的每一个值都当成一个像素点，画出图。
fig = plt.figure(figsize=(8,8*(1682./943.)))
plt.imshow(Y, cmap='rainbow')
plt.colorbar()  #图例
plt.ylabel('Movies (%d)'%nm,fontsize=20)
plt.xlabel('Users (%d)'%nu,fontsize=20)
plt.show()



#读取X、Theta的数据
mat = loadmat('ex8_movieParams.mat')
X = mat['X']
Theta = mat['Theta']
nu = int(mat['num_users'])  #用户数量943
nm = int(mat['num_movies'])  #电影数量1682
nf = int(mat['num_features'])  #每个电影和用户的特征向量是10维度


#定义展开参数和提取参数(为了使用高级优化算法，我们要将X和θ的参数量结合成一维的数组传入，在函数中再分解。)
def serialize(X, Theta):
    '''展开参数'''
    return np.r_[X.flatten(),Theta.flatten()]  #r_是按行合并

def deserialize(params, nm, nu, nf):
    '''提取参数'''
    return params[:nm*nf].reshape(nm, nf), params[nm*nf:].reshape(nu, nf)


#定义协同过滤的代价函数(Collaborative filtering cost function)
def cofiCostFunc(params, Y, R, nm, nu, nf, l=0):
    """
    params : 拉成一维之后的参数向量(X, Theta)
    Y : 评分矩阵 (nm, nu)
    R ：0-1矩阵，表示用户对某一电影有无评分
    nu : 用户数量
    nm : 电影数量
    nf : 自定义的特征的维度
    l : lambda for regularization
    
    (X@Theta)*R含义如下： 因为X@Theta是我们用自定义参数算的评分，但是有些电影本来是没有人评分的，存储在R中，0-1表示。
    将这两个相乘，得到的值就是我们要的已经被评分过的电影的预测分数。
    """
    X, Theta = deserialize(params, nm, nu, nf)
    error = 0.5*np.square((X@Theta.T - Y)*R).sum()  #np.square是平方的意思，这里的@和np.dot意思一样
    reg1 = .5*l*np.square(Theta).sum()
    reg2 = .5*l*np.square(X).sum()
    return error + reg1 +reg2


cofiCostFunc(serialize(X,Theta),Y,R,nm,nu,nf),cofiCostFunc(serialize(X,Theta),Y,R,nm,nu,nf,1.5) (22.224603725685675, 31.34405624427422)

#协同过滤的梯度
def cofiGradient(params, Y, R, nm, nu, nf, l=0):
    """
    计算X和Theta的梯度，并序列化输出。
    """
    X, Theta = deserialize(params, nm, nu, nf)
    
    X_grad = ((X@Theta.T-Y)*R)@Theta + l*X  #这里@也是dot矩阵相乘，维度弄不清的话看我的图片
    Theta_grad = ((X@Theta.T-Y)*R).T@X + l*Theta
    
    return serialize(X_grad, Theta_grad)








#获取所有电影名称(把那个txt文件的编码先另存为改成utf-8)
movies = []  # 包含所有电影的列表
with open('movie_ids.txt','r', encoding='utf-8') as f:  #文件打开后必须要close，因为文件占用系统资源，且同时打开文件的数量是有限的。with方法自动提供.close()方法
    for line in f:  #提示其中一个字符解码方式有问题，不过忽视掉就好
        movies.append(' '.join(line.strip().split(' ')[1:]))  #一共286个电影。join是用某字符连接，strip是去掉首尾某字符，split是分隔开。具体看小本本最后一页


#现在来了一个新用户，以下是他的评分
my_ratings = np.zeros((1682,1)) #某一个用户对1682个电影的评分
my_ratings[0]   = 4
my_ratings[97]  = 2
my_ratings[6]   = 3
my_ratings[11]  = 5
my_ratings[53]  = 4
my_ratings[63]  = 5
my_ratings[65]  = 3
my_ratings[68]  = 5
my_ratings[182] = 4
my_ratings[225] = 5
my_ratings[354] = 5



#读取Y、R的数据
mat = loadmat('ex8_movies.mat')
Y, R = mat['Y'], mat['R']
Y.shape, R.shape  #((1682, 943), (1682, 943))
#将刚才新用户合并到Y、R
Y = np.c_[Y, my_ratings]  #按列合并 (1682, 944)
R = np.c_[R, my_ratings!=0]  #这里!=0返回一个布尔值True或False，矩阵计算直接把True当成1 (1682, 944) 
nm, nu = Y.shape
nf = 10 # 我们使用10维的特征向量




#均值归一化数据(这个可以使一个完全没有评分的的特征最后也会获得非零值,因为要加回来。这道题我觉得没必要，因为没有完全没评分的观众)
def normalizeRatings(Y, R):
    """
    直接算评过分的电影的均值
    """
    Ymean = (Y.sum(axis=1) / R.sum(axis=1)).reshape(-1,1)  #变成一列
    Ynorm = (Y - Ymean)*R  # 不归一化未评分的数据
    return Ynorm, Ymean

Ynorm, Ymean = normalizeRatings(Y, R)
Ynorm.shape, Ymean.shape  #((1682, 944), (1682, 1))

#生成X和Theta
X = np.random.random((nm, nf))  #np.random.random是在[0, 1)均匀产生随机数
Theta = np.random.random((nu, nf))
params = serialize(X, Theta)
l = 10

#优化参数
import scipy.optimize as opt
res = opt.minimize(fun=cofiCostFunc,
                   x0=params,
                   args=(Ynorm, R, nm, nu, nf, l), #用归一化的Ynorm来训练
                   method='TNC',
                   jac=cofiGradient,
                   options={'maxiter': 100})


#利用训练好的参数来预测用户的分数
ret = res.x
fit_X, fit_Theta = deserialize(ret, nm, nu, nf)
pred = fit_X @ fit_Theta.T + Ymean  # 所有用户的剧场分数矩阵
pred_lastuser=pred[:,-1]  #最后一个用户的预测分数
pred_sorted_idx = np.argsort(pred_lastuser)[::-1] # 得到pred_lastuserd的索引1~1682,并根据pred_lastuserd的大小，将最小值的索引排前面。[::-1]翻转，使之从大到小排列。

#给这个人推荐十部电影
print("Top recommendations for you:")
for i in range(10):
    print('Predicting rating %0.1f for movie %s.' %(pred_lastuser[pred_sorted_idx[i]],movies[pred_sorted_idx[i]]))


































