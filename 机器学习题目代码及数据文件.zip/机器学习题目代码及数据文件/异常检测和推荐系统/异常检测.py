#第一个样本是定义了各个函数：第一步通过拟合两个参数生成高斯模型，第二部找到判断是否为异常点的阈值ε
#第二个样本是直接用第一个样本中的函数计算了
import pandas as pd
import numpy as np
from scipy.io import loadmat
import matplotlib.pyplot as plt

mat = loadmat('ex8data1.mat')
print(mat.keys())
X = mat['X']
Xval, yval = mat['Xval'], mat['yval']
X.shape, Xval.shape, yval.shape  #((307, 2), (307, 2), (307, 1))


#定义画出散点图
def plot_data():  #或plt.scatter(Xval[:,0], Xval[:,1], c=yval.flatten(), marker='x', cmap='rainbow')
    plt.figure(figsize=(8,5))
    plt.plot(X[:,0], X[:,1], 'bx')


plot_data()
plt.show()
    
#定义高斯函数(对原始模型和多元高斯通用，如果是原始模型则将sigma2转化成矩阵，当多元模型用。多元模型最后要加一部提取对角线的骚操作)
def gaussian(X, mu, sigma2):
    m, n = X.shape
    if np.ndim(sigma2) == 1:  #ndim是指维度，返回一个数，没括号
        sigma2 = np.diag(sigma2)  #diag可将一维数组转化成矩阵对角线，或提取矩阵对角线变成一维数组。
    P1= 1./(np.power((2*np.pi), n/2)*np.sqrt(np.linalg.det(sigma2)))
    P2=-0.5*np.dot(np.dot(X-mu,np.linalg.inv(sigma2)),(X-mu).T)
    return P1*np.exp(np.diag(P2))  #在这里提取了p2的对角元素，不然后面画图reshape的维度多了一维。也不能在前面提取，不然np.dot维度也不对。

#参数估计mu和sigma2
def getGaussianParams(X, useMultivariate):  #useMultivariate填True或False
    """
    输入的X包含m个样本，一共m行，每行是n个特征向量
    输出的mu是一个n维向量
    输出的sigma2, 是n维向量或者是(n,n)矩阵，取决于是原始模型还是多元高斯模型。
    作业这里求样本方差除的是 m 而不是 m - 1，实际上效果差不了多少。
    """
    mu = X.mean(axis=0)
    if useMultivariate:    
        sigma2 = np.dot((X-mu).T,X-mu) / len(X)
    else:
        sigma2 = X.var(axis=0, ddof=0)  # 样本方差
    
    return mu, sigma2



#画出高斯概率密度图。(在三维中是一个上凸的曲面。投影到平面上则是一圈圈的等高线。)
def plotContours(mu, sigma2):
    delta = 0.3  # 注意delta不能太小！！！否则会生成太多的数据，导致矩阵相乘会出现内存错误。
    x = np.arange(0,30,delta)
    y = np.arange(0,30,delta)
    
    xx, yy = np.meshgrid(x, y)  #计算z的话要用到gaussian函数，所以要对点的坐标格式变化成规定的X的格式。
    points = np.c_[xx.ravel(), yy.ravel()]  # 按列合并(这个按列合并是自动再转个方向...) (10000,2)。 10000行就是10000个样本点。
    z = gaussian(points, mu, sigma2)
    z = z.reshape(xx.shape)  # 这步骤不能忘
    
    cont_levels = [10**h for h in range(-20,0,3)]
    plt.contour(xx, yy, z, cont_levels)  # contour是画等高线图，cont_levels是几条等高线，这个具体题目具体分析
    
    plt.title('Gaussian Contours',fontsize=16)



# 通过原始模型画等高线
plot_data()
mu, sigma2=getGaussianParams(X, False)
plotContours(mu, sigma2)
plt.show()  #可以看到是正椭圆


# 通过多元高斯模型画等高线
plot_data()
plotContours(*getGaussianParams(X, True))  #第二种表示方法，*表示解元组
plt.show()  #可以看到是偏斜一点的椭圆



#通过交叉验证集，选择一个阈值ε，来判断哪些是异常点(正常0，异常1),使F1_score分数最高。

def selectThreshold(yval, pval):  #yval是测试集的标签，0或1。 pval是测试集通过密度函数预测得到的概率。两个都是一维数组。
    def computeF1(yval, pval):  #计算F1_score。这里pval已经由概率和ε比较从而转化成0和1
        m = len(yval)
        tp = float(len([i for i in range(m) if yval[i]==1 and pval[i]==1]))  #tp是异常值、并且我们的模型预测成异常值了
        fp = float(len([i for i in range(m) if yval[i]==0 and pval[i]==1]))  #fp是正常值、但模型把它预测成异常值
        fn = float(len([i for i in range(m) if yval[i]==1 and pval[i]==0]))  #fn是异常值，但是模型把它预测成正常值
        prec = tp/(tp+fp) #精确度
        rec = tp/(tp+fn)  #召回率
        F1 = 2*prec*rec/(prec+rec)
        return F1
   
    epsilons = np.linspace(min(pval), max(pval), 1000)
    bestF1=0
    for e in epsilons:
        pval_cppy=pval.copy()  #这里debug了一小时。凡是涉及到[]运算的一定要注意会不会改动！！
        for i in range(len(pval_cppy)):  #将一维pval中的概率转化成0和1           
            if pval_cppy[i]>e:
                pval_cppy[i]=0
            else:
                pval_cppy[i]=1
        thisF1 = computeF1(yval, pval_cppy)
        if thisF1 > bestF1:
            bestF1 = thisF1
            bestEpsilon = e
    return bestF1, bestEpsilon



mu, sigma2 = getGaussianParams(X,False)  #通过训练集训练出高斯分布的两个参数
pval = gaussian(Xval, mu, sigma2)  #用训练好的参数对测试集进行测试，高斯函数返回一个一维array，里面是测试集各个点的概率
selectThreshold(yval, pval)  #yval是测试集的标签，0或1。 pval是测试集各个点的概率。两个都是一维数组。# (0.8750000000000001, 8.999852631901397e-05)

#画出散点和高斯概率密度的等高线，然后把异常点用红色圈标注
y = gaussian(X, mu, sigma2)  # X的概率
xx = np.array([X[i] for i in range(len(y)) if y[i] < bestEpsilon])
xx  # 离群点
plot_data()  #画散点
plotContours(mu, sigma2)  #画概率等高线
plt.scatter(xx[:,0], xx[:,1], s=80, facecolors='none', edgecolors='r')  #标记异常值
plt.show()





#第二个样本，是高维的数据集
mat = loadmat( 'ex8data2.mat' )
X2 = mat['X']
Xval2, yval2 = mat['Xval'], mat['yval']
X2.shape  # (1000, 11)。一共定义了X2，Xval2，yval2三个变量


mu, sigma2 = getGaussianParams(X2, useMultivariate=False)
ypred = gaussian(X2, mu, sigma2)
yval2pred = gaussian(Xval2, mu, sigma2)


bestF1, bestEps = selectThreshold(yval2, yval2pred)  #找到最适宜的阈值ε
anoms = [X2[i] for i in range(X2.shape[0]) if ypred[i] < bestEps]  #根据得到的ε来判断训练集哪些样本是异常值
bestEps, len(anoms)  #(1.378607498200024e-18, 117) anoms是所有异常点。bestEps是ε







