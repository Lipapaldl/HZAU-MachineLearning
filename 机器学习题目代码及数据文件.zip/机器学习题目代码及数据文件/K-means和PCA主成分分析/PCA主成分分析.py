import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.io import loadmat  


mat = loadmat('ex7data1.mat')
X = mat['X']
print(X.shape)
plt.scatter(X[:,0], X[:,1], facecolors='none', edgecolors='b')
plt.show()

#先标准化
def featureNormalize(X):
    means = X.mean(axis=0)
    stds = X.std(axis=0, ddof=1)
    X_norm = (X - means) / stds
    return X_norm, means, stds

#定义协方差sgima，并做svd得到U,S,V
def pca(X):
    sigma = np.dot(X.T,X) / len(X)
    U, S, V = np.linalg.svd(sigma)
    return U, S, V

X_norm, means, stds = featureNormalize(X)
U, S, V = pca(X_norm)

#定义降维函数
def projectData(X, U, K):
    Z = np.dot(U[:,:K].T , X.T)
    return Z

Z = projectData(X_norm, U, 1)  #Z是一个2维数组，只有一行(1,50)


#定义恢复维度函数(重建数据)
def recoverData(Z, U, K):
    X_rec = np.dot(U[:,:K],Z)  #此时X是(2,50)的
    X_rec=X_rec.T  #调一下维度，每一行代表一个样本。(50,2)
    return X_rec

#(可选)画出原来点与降维后再恢复维度的点
X_rec = recoverData(Z, U, 1)
plt.figure(figsize=(7,5))
plt.axis("equal") 
plot = plt.scatter(X_norm[:,0], X_norm[:,1], s=30, facecolors='none', 
                   edgecolors='b',label='Original Data Points')
plot = plt.scatter(X_rec[:,0], X_rec[:,1], s=30, facecolors='none', 
                   edgecolors='r',label='PCA Reduced Data Points')

plt.title("Example Dataset: Reduced Dimension Points Shown",fontsize=14)
plt.xlabel('x1 [Feature Normalized]',fontsize=14)
plt.ylabel('x2 [Feature Normalized]',fontsize=14)
plt.grid(True)

for x in range(X_norm.shape[0]):
    plt.plot([X_norm[x,0],X_rec[x,0]],[X_norm[x,1],X_rec[x,1]],'k--')  #输入第一项是两个X坐标，第二项是两个Y坐标，这种可以画出两点的连线

plt.legend()
plt.show()




#人脸图像运行PCA

mat = loadmat('ex7faces.mat')
X = mat['X']
print(X.shape)  #(5000, 1024) 一共5000个样本，一个样本1024个像素

#先图片可视化
def displayData(X, row, col):
    fig, axs = plt.subplots(row, col, figsize=(8,8))
    for r in range(row):
        for c in range(col):
            axs[r][c].imshow(X[r*col + c].reshape(32,32).T, cmap = 'Greys_r')
            axs[r][c].set_xticks([])  #去除x,y轴
            axs[r][c].set_yticks([])
    plt.show()

displayData(X, 10, 10)

#对人脸数据进行标准化和pca处理
X_norm, means, stds = featureNormalize(X)
U, S, V = pca(X_norm)
U.shape, S.shape #(1024, 1024), (1024,)

#压缩成36个像素，再解压缩成1024像素。解压后数据有损失，最后画出解压后的图
z = projectData(X_norm, U, K=36)
X_rec = recoverData(z, U, K=36)
displayData(X_rec, 10, 10)
























