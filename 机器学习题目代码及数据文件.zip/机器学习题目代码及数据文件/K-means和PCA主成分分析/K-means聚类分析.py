import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.io import loadmat  #一共定义了6个函数，再用k—means时可以参考这6个函数



#定义函数：输入训练点和几个中心，得到这些点分别离哪个中心最近
def findClosestCentroids(X, centroids):
    idx = []
    for i in range(len(X)):
        minus = X[i] - centroids  #X[i]是(1,2),然而centroids是三个点即(3,2),这里做减法的话X直接自动变成三行再减，结果是(3,2)
        dist = minus[:,0]**2 + minus[:,1]**2  #将(3,2)的每行求平方和，生成一维含三个数的array，这三个数是分别到三个中心的平方和
        ci = np.argmin(dist)  #获取dist最小值的索引，即哪个中心离该样本最近
        idx.append(ci)  
    return np.array(idx)  #最后输出一个array，里面是这所有的训练集的点分别离哪个中心最近

mat = loadmat('ex7data2.mat')  # print(mat.keys())查看一下
X = mat['X']
init_centroids = np.array([[3, 3], [6, 2], [8, 5]])  #随便定义三个中心
idx = findClosestCentroids(X, init_centroids)
print(idx[0:3])  #[0 2 1] 。前三个点最近的中心

#定义函数：重新计算中心，为该中心所有点坐标的平均值。(比如如果上一步所有点都是离2中心最近，那么这部的结果就是nan。中心初始化还是有些点不行的)
def computeCentroids(X, idx): 
    centroids = []
    for i in range(len(np.unique(idx))):  # np.unique()是idx里除去重复的有哪些，得到0,1,2即那三个k
        u_k = X[idx==i].mean(axis=0)  # 求每列的平均值。X[idx==1]的意思就是X[idx里等于1的索引]。idx本身是可以与X没有关联的
        centroids.append(u_k)
    return np.array(centroids)

computeCentroids(X, idx)




#画图，不同颜色代表不同簇的分类，以及画出中心点移动轨迹
def plotData(X, centroids, idx=None):
    
    colors = ['b','g','gold','darkorange','salmon','olivedrab', 
              'maroon', 'navy', 'sienna', 'tomato', 'lightgray', 'gainsboro'
             'coral', 'aliceblue', 'dimgray', 'mintcream', 'mintcream']  #这行和下面那行就是检查颜色够不够用而已
    assert len(centroids[0]) <= len(colors), 'colors not enough '
    
    subX = []  # 分号类的样本点
    if idx is not None:  #
        for i in range(centroids[0].shape[0]):  #centroids是包含了多次移动中心的记录，centroids[0]就是第一次三个中心的坐标，维度是(3,2)。shape[0]就是行数，为3即3个中心
            x_i = X[idx == i]
            subX.append(x_i)  #subX是一个列表，含有3个元素，每个元素为每个簇的样本集，一共3个中心所以有三个元素。
    else:
        subX = [X]  # 将整个X转化为只含一个元素的列表，每个元素为每个簇的样本集，方便下方绘图
    
       # 分别画出每个簇的点，并着不同的颜色
    plt.figure(figsize=(8,5))    
    for i in range(len(subX)):
        xx = subX[i]
        plt.scatter(xx[:,0], xx[:,1], c=colors[i], label='Cluster %d'%i)
    plt.legend()
    plt.grid(True)
    plt.xlabel('x1',fontsize=14)
    plt.ylabel('x2',fontsize=14)
    plt.title('Plot of X Points',fontsize=16)
         # 画出簇中心点的移动轨迹
    xx, yy = [], []
    for centroid in centroids:
        xx.append(centroid[:,0])
        yy.append(centroid[:,1])
    
    plt.plot(xx, yy, 'rx--', markersize=8)
    plt.show()

plotData(X, [init_centroids])



#定义求K的多次循环的函数
def runKmeans(X, centroids, max_iters):  #max_iters即循环次数
    K = len(centroids)  #即中心的数量
    centroids_all = []
    centroids_all.append(centroids)
    for i in range(max_iters):
        idx = findClosestCentroids(X, centroids)
        centroids = computeCentroids(X, idx)
        centroids_all.append(centroids)
    
    return idx, centroids_all

idx, centroids_all = runKmeans(X, init_centroids, 20)
plotData(X, centroids_all, idx)



#定义随机初始化来得到初始中心点
def initCentroids(X, K):
    m = len(X)
    idx = np.random.choice(m, K)
    centroids = X[idx]  #列表里索引可以还是列表
    return centroids 



#定义行n次初始化跑程序，找到最优的那个解
def find_best_key(n,k):  #k是中心点个数
    min=10000
    for i in range(n):
        centroids = initCentroids(X, k)
        idx, centroids_all = runKmeans(X, centroids, 50)
        centroid=centroids_all[50]
        sum=0
        for i in range(k):
            subtraction = X[idx==i]-centroid[i]
            sum=sum+(subtraction**2).sum()
        if sum<min:
            min=sum
            idx_best=idx
            centroids_all_best=centroids_all
    return centroids_all_best, idx_best

centroids_all, idx=find_best_key(30,3)  #循环30次,聚成3类。2类，4类都可以
plotData(X, centroids_all, idx)







#压缩小鸟图像，24种颜色变成16种颜色
from skimage import io
'''
通过聚类算法压缩的本质是把不同类型的点当成一种类型，用相同的坐标。而坐标的维度没变
而PCA压缩的本质是降维，将高维投影到低纬，用低纬特征表示高维
'''
A = io.imread('bird_small.png')  #A的每个点数值都是unit8整数型(区别int)
print(A.shape)  #(128, 128, 3) 像素是128*128 每个像素又被表示为3位数分别代表红绿蓝的深重(0,255)
plt.imshow(A)
plt.show()
A = A/255 
'''
做除法或者与浮点型相运算后，都会变成浮点型。
imshow函数的参数要么是0~1浮点型，要么是0~255整型。
在这里直接把A除255转化成浮点型，后面就按浮点型算。避免之后再将0~255浮点转化成0~255整型
或者在这里A不除255，到后面之后A变成了浮点型，再将A转化成整型。
转化成整型用A=(np.array([int(x) for x in A.reshape(-1)])).reshape((128, 128, 3))
'''
X = A.reshape(-1, 3)  
X.shape  #(16384, 3)  #一共16384个像素，每行是一个像素
K = 16  #分成将这些像素分成16类

def findClosestCentroids(X, centroids):  #之前定义的函数做一下修改，加上一个维度
    idx = []
    for i in range(len(X)):
        minus = X[i] - centroids 
        dist = minus[:,0]**2 + minus[:,1]**2 +minus[:,2]**2  #加上minus[:,2]**2
        ci = np.argmin(dist)  #获取dist最小值的索引，即哪个中心离该样本最近
        idx.append(ci)  
    return np.array(idx)


centroids = initCentroids(X, K)
idx, centroids_all = runKmeans(X, centroids, 10)


img = np.zeros(X.shape)
centroids = centroids_all[-1]
for i in range(len(centroids)):
    img[idx == i] = centroids[i]


img = img.reshape((128, 128, 3))
fig, axes = plt.subplots(1, 2, figsize=(12,6))
axes[0].imshow(A)
axes[1].imshow(img)
plt.show()

















































