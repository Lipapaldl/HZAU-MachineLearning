import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


path =  'ex1data2.txt'
data2 = pd.read_csv(path, names=['Size', 'Bedrooms', 'Price'])
data2.head()


#特征归一化(为了使梯度下降得更方便)
data2 = (data2 - data2.mean()) / data2.std()
data2.head()

data2.insert(0, 'Ones', 1)



#定义代价函数
def computeCost(X, y, theta):
    inner = ((X@theta)-y)**2
    return np.sum(inner) / (2 * len(X))
#定义梯度下降函数
def gradient(X,y,theta):
    m=len(y)
    for i in range(1000):
        theta=theta-(0.01/97)*X.T@(X@theta-y)
    return theta

#获取设置数据
cols = data2.shape[1]
X = data2.iloc[:, :-1].as_matrix()
y = data2.iloc[:, -1].as_matrix() 
theta=np.array([0,0,0])

theta=gradient(X,y,theta)
#线性回归类模型也可以直接使用使用scikit-learn的线性回归函数
#如from sklearn import linear_model。就不用自己再从头写算法了


#拓展：画出三维图  
#出了点问题，不知道为什么要用meshgrid。直接用坐标点的话又画不出来。。
from mpl_toolkits.mplot3d import Axes3D
figure = plt.figure()
ax = fig.add_subplot(111, projection='3d')

xx=np.arange(800,4500,10) #设置坐标轴尺度
yy=np.arange(0,5,0.5)


#也可通过正规方程一步求解，具体回到网站上看。
#网站上的y是用的matrix格式，和我的arry不一样，得改一下，注意维度。
















