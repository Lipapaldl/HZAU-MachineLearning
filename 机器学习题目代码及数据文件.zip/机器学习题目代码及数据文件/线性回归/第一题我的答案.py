import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#导入数据，并查看
path =  'ex1data1.txt'
data = pd.read_csv(path, header=None, names=['Population', 'Profit'])  
data.head()
data.describe()
#数据可视化
data.plot(kind='scatter', x='Population', y='Profit', figsize=(8,5))
plt.show()


#定义代价函数
def computeCost(X, y, theta):
    inner = ((X@theta)-y)**2
    return np.sum(inner) / (2 * len(X))


#训练集中添加一列1
data.insert(0, 'Ones', 1)
#获取训练集数据
X = data.iloc[:, :-1].as_matrix()
y = data.iloc[:, -1].as_matrix() 
theta = np.zeros(X.shape[1])
#检查维度
X.shape, theta.shape, y.shape #期待输出(97, 2), (2,), (97,)



#定义梯度下降函数
def gradient(X,y,theta):
    m=len(y)
    for i in range(1000):
        theta=theta-(0.01/97)*X.T@(X@theta-y)
    return theta
#计算最终theta值
theta=gradient(X,y,theta)

fig, ax = plt.subplots(figsize=(6,4))
x = np.linspace(data.Population.min(), data.Population.max(), 100) #设置直线x坐标的数据集
y=theta[0]+theta[1]*x  #设置直线y坐标的数据集 
ax.plot(x, y, 'r', label='Prediction')   #画直线
ax.scatter(data.Population, data.Profit, label='Traning Data')  #画点，前两个参数是点的x和y坐标的数据集
ax.legend(loc=2)    #点和线的图例，2表示在左上角。不写这句的话图例出现不了
ax.set_xlabel('Population')   #接下来设置坐标轴名称和图题
ax.set_ylabel('Profit')
ax.set_title('Predicted Profit vs. Population Size')
plt.show()






