import numpy as np
import matplotlib.pyplot as plt
from scipy.io import loadmat
import scipy.optimize as opt

#读取数据
path = 'ex5data1.mat'
data = loadmat(path)
X, y = data['X'], data['y']
Xval, yval = data['Xval'], data['yval']
Xtest, ytest = data['Xtest'], data['ytest']
X = np.insert(X    ,0,1,axis=1)
Xval = np.insert(Xval ,0,1,axis=1)
Xtest = np.insert(Xtest,0,1,axis=1)
print('X={},y={}'.format(X.shape, y.shape))
print('Xval={},yval={}'.format(Xval.shape, yval.shape))
print('Xtest={},ytest={}'.format(Xtest.shape, ytest.shape))

#画出散点图
def plotData():
    """瞧一瞧数据长啥样"""
    plt.figure(figsize=(8,5))
    plt.scatter(X[:,1:], y, c='r', marker='x')  #由于这个函数里用到X，而后续还要画这个图，所以最后不能对X做改变，要用.copy()来生成X的副本
    plt.xlabel('Change in water level (x)')
    plt.ylabel('Water flowing out of the dam (y)')
    plt.grid(True)

plotData()
plt.show()

#正则化的代价函数
def costReg(theta, X, y, l):
    cost = ((X @ theta - y.flatten()) ** 2).sum()
    regterm = l * (theta[1:] @ theta[1:])
    return (cost + regterm) / (2 * len(X))

theta = np.ones(X.shape[1])
print(costReg(theta, X, y, 1))  # 303.9931922202643

#正则化梯度
def gradientReg(theta, X, y, l):
    grad = (X @ theta - y.flatten()) @ X
    regterm = l * theta
    regterm[0] = 0  # #don't regulate bias term
    return (grad + regterm) / len(X)

print(gradientReg(theta, X, y, 1))

#优化参数拟合线性回归
def trainLinearReg(X, y, l):
    theta = np.zeros(X.shape[1])
    res = opt.minimize(fun=costReg, 
                       x0=theta, 
                       args=(X, y ,l), 
                       method='TNC', 
                       jac=gradientReg)
    return res.x

fit_theta = trainLinearReg(X, y, 0)

#再次画出拟合的线
plotData()
plt.plot(X[:,1], X @ fit_theta)
plt.show()

#画出学习曲线，即交叉验证误差和训练误差随样本数量的变化的变化
def plot_learning_curve(X, y, Xval, yval, l):
    xx = range(1, len(X) + 1)  # at least has one example 
    training_cost, cv_cost = [], []
    for i in xx:
        res = trainLinearReg(X[:i], y[:i], l)
        training_cost.append(costReg(res, X[:i], y[:i], 0))
        cv_cost.append(costReg(res, Xval, yval, 0))
    plt.figure(figsize=(8,5))
    plt.plot(xx, training_cost, label='training cost')  
    plt.plot(xx, cv_cost, label='cv cost') 
    plt.legend()
    plt.xlabel('Number of training examples')
    plt.ylabel('Error')
    plt.title('Learning curve for linear regression')
    plt.grid(True)

plot_learning_curve(X, y, Xval, yval, 0)
plt.show()  #随着样本数量的增加，训练误差和交叉验证误差都很高。属于欠拟合，高偏差

#添加更多的特征，多项式回归
def genPolyFeatures(X, power):  #给训练集X添加一些X的幂的特征值
    Xpoly = X.copy()  #拷贝一个X过来，这样Xpoly的改变不会影响到X。注意copy后的括号，这里debug了一个多小时。
    for i in range(2, power + 1):
        Xpoly = np.insert(Xpoly, Xpoly.shape[1], np.power(Xpoly[:,1], i), axis=1)
    return Xpoly

def get_means_std(X):
    """获取训练集的均值和误差，用来标准化所有数据。"""
    means = np.mean(X,axis=0)
    stds = np.std(X,axis=0,ddof=1)  # ddof=1 means 样本标准差
    return means, stds

def featureNormalize(X, means, stds):
    """标准化"""
    X_norm = X.copy()
    X_norm[:,1:] = (X_norm[:,1:] - means[1:])/ stds[1:]
    return X_norm

power=6  # 扩展到x的6次方
train_means, train_stds = get_means_std(genPolyFeatures(X,power))  #注意测试集的means和stds也要用训练集的，因为模型就是这么训练的。
X_norm = featureNormalize(genPolyFeatures(X,power), train_means, train_stds)  #只是means和stds不能用整个数据集的，要用训练集的而已
Xval_norm = featureNormalize(genPolyFeatures(Xval,power), train_means, train_stds)
Xtest_norm = featureNormalize(genPolyFeatures(Xtest,power), train_means, train_stds)

#画出拟合图
def plot_fit(means, stds, l):
    """画出拟合曲线"""
    theta = trainLinearReg(X_norm,y, l)
    x = np.linspace(-75,55,50)  #为了画曲线，画50个点代表曲线
    xmat = x.reshape(-1, 1)  #把50个点变成训练集自变量的格式
    xmat = np.insert(xmat,0,1,axis=1)  #插入1
    Xmat = genPolyFeatures(xmat, power)  #变成6次方的形式
    Xmat_norm = featureNormalize(Xmat, means, stds)  #减均值除以标准差来标准化
    plotData()
    plt.plot(x, Xmat_norm@theta,'b--')  #那50个点乘theta，画出曲线。

plot_fit(train_means, train_stds, 0)
plot_learning_curve(X_norm, y, Xval_norm, yval, 0)
plt.show()  #λ = 0时，训练误差太小了，明显过拟合了

plot_fit(train_means, train_stds, 1)
plot_learning_curve(X_norm, y, Xval_norm, yval, 1)
plt.show()  #λ = 1

plot_fit(train_means, train_stds, 100)
plot_learning_curve(X_norm, y, Xval_norm, yval, 100)
plt.show()  #λ = 100时,很明显惩罚过多，欠拟合了

#设置不同的λ，通过cross validation集来测试
lambdas = [0., 0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1., 3., 10.]
errors_train, errors_val = [], []
for l in lambdas:
    theta = trainLinearReg(X_norm, y, l)
    errors_train.append(costReg(theta,X_norm,y,0))  # 注意，计算error时不用加正则惩罚了，已经不用计算梯度了，这跟代价函数还是有区别的。
    errors_val.append(costReg(theta,Xval_norm,yval,0))

#画出图，训练集和cross validation集的error关于λ的函数
plt.figure(figsize=(8,5))
plt.plot(lambdas,errors_train,label='Train')
plt.plot(lambdas,errors_val,label='Cross Validation')
plt.legend()
plt.xlabel('lambda')
plt.ylabel('Error')
plt.grid(True)
plt.show()

lambdas[np.argmin(errors_val)]  #np.argmin是返回最小值在数组中的位置，加上lambdas就是得到最小的值了 3.0 设计更精确的梯度后是2.28

theta = trainLinearReg(X_norm, y, 3)
print('test cost(l={}) = {}'.format(3, costReg(theta, Xtest_norm, ytest, 0)))  #test cost(l=3) = 4.7552720391599
  


















