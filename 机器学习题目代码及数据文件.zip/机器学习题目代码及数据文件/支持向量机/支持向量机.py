#最全做法参考样本3
#也可以直接参考(上面有参数)https://www.jb51.net/article/145038.htm
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
from scipy.io import loadmat
from sklearn import svm



#样本1：线性分类
mat = loadmat('ex6data1.mat')
print(mat.keys())
#可视化画出散点图，根据y的0和1区分颜色
def plotData(X, y):
    plt.figure(figsize=(8,5))
    plt.scatter(X[:,0], X[:,1], c=y.flatten(), cmap='rainbow')  #X第0列为x坐标，第1列为y坐标，c颜色按照y的0和1来区分。根据'rainbow'对应数字颜色
    plt.xlabel('X1')
    plt.ylabel('X2')

plotData(X, y)
plt.show()
#定义画出网格线和边界线
def plotBoundary(clf, X):  #clf是指训练好的模型(已经求好theta)
    x_min, x_max = X[:,0].min()*1.2, X[:,0].max()*1.1
    y_min, y_max = X[:,1].min()*1.1,X[:,1].max()*1.1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 500),
                         np.linspace(y_min, y_max, 500))
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])  #np.c按行拼接数组，np.r按列拼接数组。
    Z = Z.reshape(xx.shape)
    plt.contour(xx, yy, Z)
#定义SVM的C值，然后根据X和y训练两个模型，包含在clfs中
models = [svm.SVC(C, kernel='linear') for C in [1, 100]]
clfs = [model.fit(X, y.ravel()) for model in models]  #flatten是返回一份拷贝，对原始矩阵没影响。ravel对原始有影响
#调用定义的函数画出边界线图
title = ['SVM Decision Boundary with C = {} (Example Dataset 1'.format(C) for C in [1, 100]]
for model,title in zip(clfs,title):  #如图可看到改变C值对边界线的影响
    plt.figure(figsize=(8,5))
    plotData(X, y)
    plotBoundary(model, X)
    plt.title(title)
    plt.show()


#接下来两段是对以上内容的另一个版本测试，格式是我熟悉的格式
#训练模型和定义网格线
models2=svm.SVC(50,kernel='linear')  #C等于50时
clfs2=models2.fit(X,y.ravel())  #用X和y训练出模型
x_min, x_max = X[:,0].min()*1.2, X[:,0].max()*1.1  #接下来三行来画网格线
y_min, y_max = X[:,1].min()*1.1,X[:,1].max()*1.1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 500),np.linspace(y_min, y_max, 500))  #若改成10，那么边界线就是10个点连线的折线图了
z=clfs2.predict(np.c_[xx.ravel(),yy.ravel()])  #用训练好的模型对网格点进行预测，参数只有一个，所以要将横纵坐标展开后连接。.predict是预测边界线
z=z.reshape(xx.shape)  #将预测好的z维度调回网格的维度
#画图 两幅图放一起的话，用一个plt.figure就行了。plt.figure在plotData里出现过，所以不用再定义了
plotData(X, y)
plt.contour(xx,yy,z)  #contour是专门画网格的，它的三个参数对应好网格
plt.show()



#样本2：非线性分类
def gaussKernel(x1, x2, sigma):
    return np.exp(- ((x1 - x2)**2).sum() / (2 * sigma ** 2))

gaussKernel(np.array([1, 2, 1]),np.array([0, 4, -1]), 2.)  # 0.32465246735834974

mat = loadmat('ex6data2.mat')  #装载第二份数据
X2 = mat['X']
y2 = mat['y']
plotData(X2, y2)
plt.show()

sigma = 0.1
gamma = np.power(sigma,-2.)/2
modle = svm.SVC(C=1, kernel='rbf', gamma=gamma)  #
clf = modle.fit(X2, y2.flatten())
plotData(X2, y2)
plotBoundary(modle, X2)  #这里用modle或clf都行，只要之前用modle.fit训练过就行了。
plt.show()



#样本3
mat3 = loadmat('ex6data3.mat')
X3, y3 = mat3['X'], mat3['y']
Xval, yval = mat3['Xval'], mat3['yval']  #指测试验证集，用于计算f1score来评估模型好坏
plotData(X3, y3)
plt.show()
  #为接下来选一个合适的C和sigma做准备
Cvalues = (0.01, 0.03, 0.1, 0.3, 1., 3., 10., 30.)  
sigmavalues = (0.01, 0.03, 0.1, 0.3, 1., 3., 10., 30.)
best_score=0 
  #找到最适C和sigma
for C in Cvalues:  
    for sigma in sigmavalues:
        gamma = np.power(sigma,-2.)/2
        model = svm.SVC(C=C,kernel='rbf',gamma=gamma)
        model.fit(X3, y3.flatten())
        this_score = model.score(Xval, yval)
        if this_score > best_score:
            best_score = this_score
            best_pair = (C, sigma)
#打印出找到的结果
print('best_pair={}, best_score={}'.format(best_pair, best_score))   # best_pair=(1.0, 0.1), best_score=0.965
#用得到的参数训练模型，画出边界线
model = svm.SVC(C=1., kernel='rbf', gamma = np.power(0.1, -2)/2)
model.fit(X3, y3.flatten())
plotData(X3, y3)
plotBoundary(model, X3)
plt.show()



























