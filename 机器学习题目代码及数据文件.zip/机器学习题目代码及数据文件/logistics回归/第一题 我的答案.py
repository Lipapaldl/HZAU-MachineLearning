#本文档不要直接复制到命令行，函数之间定义时可能要空一行

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


data = pd.read_csv('ex2data1.txt', names=['exam1', 'exam2', 'admitted'])
data.head()
data.describe()



#接下来画出散点图，横纵坐标是两门考试分数。蓝色代表通过。
positive = data[data.admitted.isin(['1'])] 
negetive = data[data.admitted.isin(['0'])]

fig, ax = plt.subplots(figsize=(6,5))
ax.scatter(positive['exam1'], positive['exam2'], c='b', label='Admitted')
ax.scatter(negetive['exam1'], negetive['exam2'], s=50, c='r', marker='x', label='Not Admitted')
# 设置图例显示在图的上方
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width , box.height* 0.8])
ax.legend(loc='center left', bbox_to_anchor=(0.2, 1.12),ncol=3)
# 设置横纵坐标名
ax.set_xlabel('Exam 1 Score')
ax.set_ylabel('Exam 2 Score')

plt.show() #如图



#定义logistic函数
def sigmoid(z):  
    return 1 / (1 + np.exp(- z))
#检查一下它是否正确
x1 = np.arange(-10, 10, 0.1)
plt.plot(x1, sigmoid(x1), c='r')
plt.show()



#定义代价cost函数
def cost(theta, X, y):
    first = (-y) * np.log(sigmoid(X @ theta)) #注意array中有三种乘法
    second = (1 - y)*np.log(1 - sigmoid(X @ theta))
    return np.mean(first - second)
    

#设置训练集数据和theta
if 'Ones' not in data.columns:   #加一列x=1的。
    data.insert(0, 'Ones', 1)
X = data.iloc[:, :-1].as_matrix()   #设置X和y
y = data.iloc[:, -1].as_matrix()  
theta = np.zeros(X.shape[1])
#检查一下是否正确
X.shape, theta.shape, y.shape   # 期待输出((100, 3), (3,), (100,))
cost(theta, X, y)   # 期待输出0.6931471805599453



#定义批量的梯度。这是一个theta的导数的公式
def gradient(theta, X, y):
    return (X.T @ (sigmoid(X @ theta) - y))/len(X)  通过X.T使最后结果得到一个theta的向量，就不用分开theta[0],theta[1]这种了。


#通过高级优化来进行梯度下降（计算速度很快，且不需要人为设定α）
import scipy.optimize as opt
result = opt.fmin_tnc(func=cost, x0=theta, fprime=gradient, args=(X, y))  #通过fmin_tnc来优化。另一种方法在网页上。
result   #期待输出(array([-25.16131867,   0.20623159,   0.20147149]), 36, 0)
#此时[-25.16131867,   0.20623159,   0.20147149]为预测的theta值。



#扩展：找到决策边界
#即当sigmoid函数为0.5时，即z为0时，即θ+ θ0x1 + θ2x2 = 0时。 图像的横纵坐标为x1和x2
final_theta = result[0] #先获得刚才所求的theta
x1 = np.arange(130, step=0.1)  #设定x轴尺寸标度
x2 = -(final_theta[0] + x1*final_theta[1]) / final_theta[2] #此时可以把x2看成是一个关于x1的函数
#接下来作图
fig, ax = plt.subplots(figsize=(8,5))
ax.scatter(positive['exam1'], positive['exam2'], c='b', label='Admitted') #采集点的数据，蓝色点代表通过
ax.scatter(negetive['exam1'], negetive['exam2'], s=50, c='r', marker='x', label='Not Admitted') #采集点的数据，红色叉表示未通过
ax.plot(x1, x2)
ax.set_xlim(0, 130)   #x轴长度
ax.set_ylim(0, 130)   #y轴长度
ax.set_xlabel('x1')   #x，y轴名称
ax.set_ylabel('x2')
ax.set_title('Decision Boundary')  #图题
plt.show()



