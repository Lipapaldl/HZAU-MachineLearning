import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data2 = pd.read_csv('ex2data2.txt', names=['Test 1', 'Test 2', 'Accepted'])
data2

#画出散点图，观察是否呈线性
def plot_data():
    positive = data2[data2['Accepted'].isin([1])] #将Accepted列中是1的数据提出来，单独呈一个表格
    negative = data2[data2['Accepted'].isin([0])] #同上，提出Accepted是0的表格
    #接下来画图
    fig, ax = plt.subplots(figsize=(8,5))
    ax.scatter(positive['Test 1'], positive['Test 2'], s=50, c='b', marker='o', label='Accepted')
    ax.scatter(negative['Test 1'], negative['Test 2'], s=50, c='r', marker='x', label='Rejected')
    ax.legend() #画出图例
    ax.set_xlabel('Test 1 Score')
    ax.set_ylabel('Test 2 Score')


plot_data()
plt.show()  #注意到其中的正负两类数据并没有线性的决策界限。

#定义一个特征映射函数：直到六次幂
def feature_mapping(x1, x2, power):
    data = {}    #定义一个字典，从而在之后可以直接添加元素的名称和内容
    for i in np.arange(power + 1):    #i=n时，就是n次幂的所有组合。一共最多power次幂
        for p in np.arange(i + 1):
            data["f{}{}".format(i - p, p)] = np.power(x1, i - p) * np.power(x2, p)  #format是格式化函数。
    return pd.DataFrame(data)  #将字典转化为一种二维表，类似excel
    

#初始化数据
x1 = data2['Test 1'].as_matrix()   #定义x1，x2的数据
x2 = data2['Test 2'].as_matrix()
_data2 = feature_mapping(x1, x2, power=6)  #得到特征映射后的二维表
_data2.head()
X = _data2.as_matrix()   #将二维表转化为array格式
y = data2['Accepted'].as_matrix()  #初始化y
theta = np.zeros(X.shape[1])
X.shape, y.shape, theta.shape  #检查维度，期待输出((118, 28), (118,), (28,))

#定义代价函数：正则化的代价函数，解决过拟合现象
def cost(theta, X, y):    #这是未正则化的代价函数（之前的那个）
    first = (-y) * np.log(sigmoid(X @ theta)) #注意array中有三种乘法
    second = (1 - y)*np.log(1 - sigmoid(X @ theta))
    return np.mean(first - second)

def sigmoid(z):  #之前那个代价函数要用到这个logist函数
    return 1 / (1 + np.exp(- z))

def costReg(theta, X, y, l=1):   #这是正则化之后的代价函数
    _theta = theta[1: ]  #不惩罚第一项
    reg = (l / (2 * len(X))) *(_theta @ _theta)  
    return cost(theta, X, y) + reg   #即之前那个代价函数再加一部分
    
#定义批量的梯度函数：同样是正则化后的，是那个导数
def gradient(theta, X, y):   #这是之前未正则化的那个
    return (X.T @ (sigmoid(X @ theta) - y))/len(X)
    
def gradientReg(theta, X, y, l=1):  #这是正则化后的
    reg = (1 / len(X)) * theta
    reg[0] = 0    #同样不惩罚第一个θ
    return gradient(theta, X, y) + reg
    gradientReg(theta, X, y, 1)  #这个结果和网页上的那个结果顺序不一样，但是本质相同
#通过高级优化来进行梯度下降（计算速度很快，且不需要人为设定α）
import scipy.optimize as opt
result2 = opt.fmin_tnc(func=costReg, x0=theta, fprime=gradientReg, args=(X, y, 2))  #另一种优化方法在网页上

#判断拟合的模型结果的精确性
final_theta = result2[0]
def predict(theta, X):
    probability = sigmoid(X@theta)
    return [1 if x >= 0.5 else 0 for x in probability] 
predictions = predict(final_theta, X)
correct = [1 if a==b else 0 for (a, b) in zip(predictions, y)]  #通过模型预测的结果与真实结果相比
accuracy = sum(correct) / len(correct)
accuracy  #输出0.8多



#画出决策边界：不能像第一题那样ax.plot(x,y)那样画了，因为那样要列出y等于多少多少x,把y看成x的函数。这里幂太高式子复杂，很难变形。
#xx，yy是指二维图上的所有点（网格线）。
#思路是：1.初始化网格点 2.所有网格点变成高次幂的形式、再×theta。这个式子命名为z，z等于0时，y=0.5。contour函数是默认z=0
x = np.linspace(-1, 1.5, 250)  #x维度是250
xx, yy = np.meshgrid(x, x)  #xx维度是250,250  xx.ravel()的维度是62500，ravel即多维数组转化为一维数组,后面featuremapping的参数是要一维的。
z = feature_mapping(xx.ravel(), yy.ravel(), 6).as_matrix()  #z的维度是62500,28
z = z @ final_theta  #z的维度是62500
z = z.reshape(xx.shape)  #z的维度是250,250
plot_data()  #这个是一开始定义的那个函数，即执行后画出散点图.
plt.contour(xx, yy, z, 0)  #这里z是一个关于xx、yy的高次幂的函数，默认z=0画图
plt.ylim(-.8, 1.2)
plt.show()  #最后显图，注意要所有元素都定义过后才能显图




<!-- 我的测试：1.六次幂不正则化的过拟合图像、二十次幂的正则化和非正则化
我的测试：2.用本题的最后画图的contour(xx, yy, z, 0)方法来画第一题的图，结果和第一题完全一样。
我认为这是一种普遍的方法，以后都用这种了。就是注意xx和yy是二维网格，z的维度要和他们相同。z是默认关于xx和yy的函数为0 -->











    